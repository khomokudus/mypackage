from . import myModule
